# Helpdesk-system
A support system to eradicate manual ways of processing complaints in any  company.
This system was implemented using:Bootstrap,CSS3, HTML5, Javascript, Photoshop, PHP and Mysql for the back-end.
  ###############################################################################################
You can successfull used this code if and if you have Xamp/Wamp server installed in your system then import the database into your xamp but ensure the name of your database is the same with the one in this system.
