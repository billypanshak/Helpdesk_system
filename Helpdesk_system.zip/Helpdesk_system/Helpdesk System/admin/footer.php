<style type="text/css">
.fa-youtube{
    font-size: 50px;
    color:#bb0000;

}
.fa-youtube:hover{
 cursor: pointer;
 color:#d5d5d5;
} 
.fa-facebook{
    font-size: 50px;
    color: #3b5998;
    cursor: pointer;
}
.social{
    color: white;
    margin-left: 45%;
}
.fa-facebook:hover{
color: #d5d5d5;
}
.fa-facebook{
    color: #3b5998;
}
.fa-twitter{
    color: #00aced;
    font-size: 50px;
}
.fa-google-plus{
    color:#ff9900;
    font-size: 50px;
}
.fa-instagram{
    font-size: 50px;
    color:#517fa4;
}
.fa-linkedin{
    font-size: 50px;
    color:#517fa4;
}
.fa-linkedin:hover{
  color: #d5d5d5;  
}
.fa-google{
     font-size: 50px;
    color:brown; 
}
.fa-facebook:hover,
.fa-twitter:hover,
.fa-google:hover,
.fa-instagram:hover,
.fa-youtube:hover{
  color: #d5d5d5;
}
p{
    margin-left: 10%;
}
 </style>
 
        <hr>
        <b class="social"><u>Our Social Media Handles</u></b>
        <div class="col-12">
        <p class="fa fa-facebook" ></p>
        <p class="fa fa-twitter"></p>
        <p class="fa fa-youtube"></p>
        <p class="fa fa-linkedin"></p>
        <p class="fa fa-google"></p>
        <p class="fa fa-instagram"></p>
    </div>
    </div>
    <div class="panel-footer" style="margin-bottom: -40px">
        <h5 style="text-align: center;"><b>All &copy Right Reserved @ Bintech 2020</b></h5>
    </div>
   </footer>
   </div>
    <script src="/Helpdesk System/sections/assets/jquery.min.js"></script>
    <script src="/Helpdesk System/sections/assets/bootstrap.min.js"></script>
    </body>
    </html>