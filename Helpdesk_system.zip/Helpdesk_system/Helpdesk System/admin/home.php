<?php 
include("header_admin.php");
include("../db/connect.php");

?>
<?php  include("../users/session.php");?>

 <div class="jumbotron" style="height:400px; margin: 0 auto; border-radius:5px">
 </div>
<?php 
include("footer.php");
?>